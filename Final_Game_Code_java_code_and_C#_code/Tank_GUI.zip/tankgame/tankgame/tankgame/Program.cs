using System;
using System.Threading;

namespace tankgame
{
#if WINDOWS || XBOX
    static class Program
    {

        static void Main(string[] args)
        {

            using (GameCore game = new GameCore())
            {
               // Connection cnt = new Connection();
              //  cnt.connect();
                Console.WriteLine("I'm in the initialize method");
                GetMessege msg = new GetMessege();
                Thread t = new Thread(GetMessege.getMessage);
                t.Start();
                game.Run();
            }


        }
    }
#endif
}

