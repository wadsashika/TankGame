﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Net.Sockets;


namespace tankgame
{
    public class Connection
    {

        public void connect()
        {

            try
            {
                TcpClient tcpclnt = new TcpClient();
                Console.WriteLine("Connecting.....");

                tcpclnt.Connect("10.0.0.2", 8000);
                Console.WriteLine("Connected");
                String str = "JOIN#";
                NetworkStream netStm = tcpclnt.GetStream();

                ASCIIEncoding ascEn = new ASCIIEncoding();
                byte[] bArry = ascEn.GetBytes(str);
                netStm.Write(bArry, 0, bArry.Length);
                Console.WriteLine("\nSent JOIN#");


                netStm.Close();

                tcpclnt.Close();
            }

            catch (Exception e)
            {
                Console.WriteLine("Error..... " + e.StackTrace);
                GameCore game = new GameCore();
                game.Exit();
            }
        }

    }
}
