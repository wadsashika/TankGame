﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lk.ac.mrt.cse.pc11.bean
{   
    //Coicider merging with the parent
    class LifePack : MapItem
    {
        public LifePack(int x, int y): base(x, y)
        {

        }
    }
}
