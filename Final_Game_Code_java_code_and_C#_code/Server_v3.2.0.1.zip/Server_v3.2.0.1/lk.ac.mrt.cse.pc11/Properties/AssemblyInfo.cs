﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("lk.ac.mrt.cse.pc11")]
[assembly: AssemblyDescription("Tanks - Programming Competition CSE")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Nutshell (Revised by N.H.N.D. de Silva)")]
[assembly: AssemblyProduct("lk.ac.mrt.cse.pc11")]
[assembly: AssemblyCopyright("Original: Copyright © Nutshell 2009 (Revision: Copyright © N.H.N.D. de Silva 2009 & 2011)")]
[assembly: AssemblyTrademark("Original: prasnuts(TM) (Revision: [facebook|Twitter]/NisansaDdS) ")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("8e89dc19-2c09-4732-8557-bdbab265acca")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("3.2.0.0")]
[assembly: AssemblyFileVersion("3.2.0.0")]
